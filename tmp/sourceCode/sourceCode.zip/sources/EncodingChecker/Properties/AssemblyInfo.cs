﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("File Encoding Checker")]
[assembly: AssemblyDescription("GUI tool to check the encoding of a text file")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Jeevan James")]
[assembly: AssemblyProduct("File Encoding Checker")]
[assembly: AssemblyCopyright("Copyright © Jeevan James 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
